package pl.gempxplay.wolfsk;

import pl.gempxplay.wolfsk.util.IOUtils;

public class ConnectionTest {

    public static void main(String[] args) {
        String content = IOUtils.getContent("http://opengate.cba.pl/ftp_server/GempXPlay_gzdp8w/minecraft/WildSkript/wersja.txt");
        System.out.println("Content: " + content);
    }

}
