package pl.gempxplay.wolfsk;

import ch.njol.skript.Skript;
import pl.gempxplay.wolfsk.events.PlayerJoin;
import pl.gempxplay.wolfsk.events.PlayerMove;
import pl.gempxplay.wolfsk.events.ServerPing;
import pl.gempxplay.wolfsk.objects.inventory.InventoryEvent;
import pl.gempxplay.wolfsk.objects.recipe.RecipesEvent;
import pl.gempxplay.wolfsk.objects.recipe.ResultEvent;
import pl.gempxplay.wolfsk.register.Register;
import pl.gempxplay.wolfsk.util.IOUtils;
import pl.gempxplay.wolfsk.util.Metrics;
import pl.gempxplay.wolfsk.util.User;
import pl.gempxplay.wolfsk.util.WildSkriptTimer;
import pl.gempxplay.wolfsk.util.Metrics.Graph;
import pl.gempxplay.wolfsk.util.data.Data;
import pl.gempxplay.wolfsk.util.doc.Documentation;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.IOException;

public class WolfSk extends JavaPlugin {

    private static WolfSk wolfsk;
    public static String version;
    public static boolean debug;
    public static String lang;

    private static boolean enable;
    private static boolean skript;
    private static boolean skQuery;
    private static boolean randomSk;
    private static boolean skUtilities;
    
    String l;
    String vWarning;

    private static WildSkriptTimer timer;

    @Override
    public void onEnable() {

        // Register this
        wolfsk = this;

        // Check
        if (cannot()) {
            return;
        }

        // Data start
        Data.load();

        // BungeeCord channel
        bungee();

        // Init utils
        utils();

        // Register Events Listener
        Bukkit.getPluginManager().registerEvents(new ServerPing(), this);
        Bukkit.getPluginManager().registerEvents(new InventoryEvent(), this);
        Bukkit.getPluginManager().registerEvents(new PlayerMove(), this);
        Bukkit.getPluginManager().registerEvents(new PlayerJoin(), this);
        Bukkit.getPluginManager().registerEvents(new RecipesEvent(), this);
        Bukkit.getPluginManager().registerEvents(new ResultEvent(), this);

        // Register WildSkript
        Skript.registerAddon(this);

        // Register WildSkript Functions
        Register.register();

        // Documentation
        if (Data.doc) {
            Documentation.generate();
        }
        if (Data.mcstats) {
            metrics();
        }

        if(lang.contains("pl")) {
        	l = "pl";
        	log("Ustawiono jezyk na - Polski (pl)");
        } else {
        	log("Changed language to - English (en)");
        }
        
        if(version.contains("beta")) {
        	vWarning = "[ ! BETA ! ]";
        } else if(version.contains("alpha")) {
        	vWarning = "[ -!- ALPHA -!- ]";
        } else if(version.contains("dev")) {
        	vWarning = "[ ->!-< DEV >-!-< ]";
        } else {
        	vWarning = "[ RELEASED ]";
        }
        
        if(l == "pl") {
        	log("~------------------<[  WolfSk  ]>------------------~");
        	log("Autor: GempXPlay");
        	log("Wersja: " + getVersion() + " " + vWarning);
        	log("Data budowy: 27.04.2020 (16:45)");
        	log("Tworzone za zgoda autora pluginu.");
        	log("Tworzymy te aktualizacje z <3 do graczy.");
        	log("~------------------<[  WolfSk  ]>------------------~");
        } else {
        	log("~------------------<[  WolfSk  ]>------------------~");
        	log("Author: GempXPlay");
        	log("Version: " + getVersion() + " " + vWarning);
        	log("Build date: 27.04.2020 (16:45)");
        	log("We make this update with <3 for players.");
        	log("~------------------<[  WolfSk  ]>------------------~");
        }

        checkUpdate();
    }

    private boolean cannot() {
        for (Plugin plugin : Bukkit.getPluginManager().getPlugins()) {
            if (plugin.getName().equalsIgnoreCase("skript")) {
            	if(l == "pl") {
                	log("Polaczono ze SKRIPT-em");
                } else {
                	log("Connected with SKRIPT");
                }
                skript = true;
            }
            if (plugin.getName().equalsIgnoreCase("skQuery")) {
            	if(l == "pl") {
                	log("Polaczono ze SkQuery");
                } else {
                	log("Connected with SkQuery");
                }
                skQuery = true;
            }
            if (plugin.getName().equalsIgnoreCase("randomSk")) {
            	if(l == "pl") {
                	log("Polaczono ze RandomSk");
                } else {
                	log("Connected with RandomSk");
                }
                randomSk = true;
            }
            if (plugin.getName().equalsIgnoreCase("skUtilities")) {
            	if(l == "pl") {
                	log("Polaczono ze SkUtilities");
                } else {
                	log("Connected with SkUtilities");
                }
                skUtilities = true;
            }
        }
        if (!skript) {
        	if(l == "pl") {
            	warning("Nie mozna odnalesc Skript-u w folderze plugins, pobierz Skript i przenies do folderu plugins. Po wykonaniu tego przeladuj lub zresetuj serwer.");
            } else {
            	warning("Can't find Skript in plugins!, download Skript and put in plugins folder. After this please reload or restart server.");
            }
            return true;
        }
        enable = true;
        return false;
    }

    private void metrics() {
        try {
            Metrics metrics = new Metrics(wolfsk);
            Graph global = metrics.createGraph("Global Statistics Linear");
            global.addPlotter(new Metrics.Plotter("Servers") {
                @Override
                public int getValue() {
                    return 1;
                }
            });
            global.addPlotter(new Metrics.Plotter("Players") {
                @Override
                public int getValue() {
                    return Bukkit.getOnlinePlayers().size();
                }
            });
            metrics.addGraph(global);
            metrics.start();
        } catch (IOException e) {
            log(e.getMessage());
        }
    }

    private void checkUpdate() {
        final Thread thread = new Thread() {
            public void run() {
                String latest = IOUtils.getContent("http://opengate.cba.pl/ftp_server/GempXPlay_gzdp8w/minecraft/WildSkript/wersja.txt");
                if (latest == null || latest.isEmpty()) {
                	if(l == "pl") {
                    	update("Uuups!, nie udalo sie sprawdzic najnowszej wersji WolfSk.");
                	} else {
                        update("Ooops!, failed to check the new version of WolfSk.");
                	}
                }
                else if (latest.equalsIgnoreCase(getVersion())) {
                	if(lang.contains("pl")) {
                        update("Uzywasz najnowszej wersji WolfSk");
                	} else {
                        update("You're using latest version of WolfSk");
                	}
                }
                else {
                	if(l == "pl") {
                		update("");
                		update("[ > ] Aktualizacja [ < ]");
                		update("   Uzywana: " + getVersion());
                		update("   Najnowsza: " + latest);
                		update("");
                	} else {
                        update("");
                        update("[ > ] Update available [ < ]");
                        update("   Used: " + getVersion());
                        update("   Latest: " + latest);
                        update("");	
                	}
                }
            }
        };
        thread.start();
    }

    private void bungee() {
        Bukkit.getMessenger().registerOutgoingPluginChannel(wolfsk, "BungeeCord");
    }

    private void utils() {
        timer = new WildSkriptTimer();
        Bukkit.getScheduler().scheduleSyncRepeatingTask(this, timer, 1000L, 50L);
        for (Player p : Bukkit.getOnlinePlayers()) {
            User.get(p);
        }
    }

    public static WolfSk getInstance() {
        return wolfsk;
    }

    public static String getVersion() {
        return version;
    }

    public static WildSkriptTimer getTimer() {
        return timer;
    }

    public static void update(String content) {
        Bukkit.getLogger().info("[WolfSk :: UPDATE] -> " + content);
    }

    public static void log(String log) {
        Bukkit.getLogger().info("[WolfSk] " + log);
    }

    public static void severe(String log) {
        Bukkit.getLogger().severe("[WolfSk] " + log);
    }

    public static void warning(String log) {
        Bukkit.getLogger().severe("[WolfSk :: WARNING] #!#");
        Bukkit.getLogger().severe("[WolfSk :: WARNING] #!# ======={ :: WARNING :: }=======");
        Bukkit.getLogger().severe("[WolfSk :: WARNING] #!# " + log);
        Bukkit.getLogger().severe("[WolfSk :: WARNING] #!#");
    }

    public static void error(String log) {
        Bukkit.getLogger().severe("[WolfSk :: ERROR] #!#");
        Bukkit.getLogger().severe("[WolfSk :: ERROR] #!# =!!!======{ ::!:: ERROR ::!:: }======!!!=");
        Bukkit.getLogger().severe("[WolfSk :: ERROR] #!# " + log);
        Bukkit.getLogger().severe("[WolfSk :: ERROR] #!#");
        Bukkit.getLogger().severe("[WolfSk :: ERROR] #!#");
    }

    public static boolean skQuery() {
        return skQuery;
    }

    public static boolean randomSk() {
        return randomSk;
    }
    
    public static boolean skUtilities() {
        return skUtilities;
    }

    public static boolean enabled() {
        return enable;
    }

    public static boolean debug() {
        return debug;
    }
}
   
    
   
   
   
   
   
 
