package pl.gempxplay.wolfsk.objects;

import pl.gempxplay.wolfsk.objects.hashmap.SkriptHashMapElements;
import pl.gempxplay.wolfsk.objects.hologram.HologramElements;
import pl.gempxplay.wolfsk.objects.inventory.InventoryElements;
import pl.gempxplay.wolfsk.objects.mysql.MySQLElements;
import pl.gempxplay.wolfsk.objects.recipe.RecipesElements;
import pl.gempxplay.wolfsk.objects.region.RegionsElements;
import pl.gempxplay.wolfsk.objects.scoreboard.ScoreboardsElements;
import pl.gempxplay.wolfsk.objects.tab.TabElements;

public class Objects {

    public static void registerObjects() {
        InventoryElements.register();
        SkriptHashMapElements.register();
        RegionsElements.register();
        TabElements.register();
        RecipesElements.register();
        ScoreboardsElements.register();
        HologramElements.register();
        MySQLElements.register();
    }
}
