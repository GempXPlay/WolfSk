package pl.gempxplay.wolfsk.objects.region.elements;

import ch.njol.skript.doc.NoDoc;
import ch.njol.skript.lang.Expression;
import ch.njol.skript.lang.SkriptParser;
import ch.njol.skript.lang.util.SimpleExpression;
import ch.njol.util.Kleenean;
import pl.gempxplay.wolfsk.objects.region.RegionsUtils;

import org.bukkit.Location;
import org.bukkit.event.Event;

@NoDoc
public class ExprP extends SimpleExpression<Location> {

    private Expression<String> id;

    protected Location[] get(Event event) {

        String id = this.id.getSingle(event);

        Location loc = RegionsUtils.get(id).getP();
        return new Location[]{ loc };

    }

    @SuppressWarnings("unchecked")
    public boolean init(Expression<?>[] e, int i, Kleenean kleenean, SkriptParser.ParseResult parseResult) {
        this.id = (Expression<String>) e[0];
        return true;
    }

    public boolean isSingle() {
        return true;
    }

    public Class<? extends Location> getReturnType() {
        return Location.class;
    }

    public String toString(Event event, boolean b) {
        return "";
    }
}


	

