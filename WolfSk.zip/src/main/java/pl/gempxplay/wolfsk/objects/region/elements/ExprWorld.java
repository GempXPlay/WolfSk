package pl.gempxplay.wolfsk.objects.region.elements;

import ch.njol.skript.doc.NoDoc;
import ch.njol.skript.lang.Expression;
import ch.njol.skript.lang.SkriptParser;
import ch.njol.skript.lang.util.SimpleExpression;
import ch.njol.util.Kleenean;
import pl.gempxplay.wolfsk.objects.region.RegionsUtils;

import org.bukkit.World;
import org.bukkit.event.Event;

@NoDoc
public class ExprWorld extends SimpleExpression<World> {

    private Expression<String> id;

    protected World[] get(Event event) {

        String id = this.id.getSingle(event);

        World world = RegionsUtils.get(id).getWorld();
        return new World[]{ world };

    }

    @SuppressWarnings("unchecked")
    public boolean init(Expression<?>[] e, int i, Kleenean kleenean, SkriptParser.ParseResult parseResult) {
        this.id = (Expression<String>) e[0];
        return true;
    }

    public boolean isSingle() {
        return true;
    }

    public Class<? extends World> getReturnType() {
        return World.class;
    }

    public String toString(Event event, boolean b) {
        return "";
    }
}


	

