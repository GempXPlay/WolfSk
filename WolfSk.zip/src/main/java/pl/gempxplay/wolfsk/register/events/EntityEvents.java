package pl.gempxplay.wolfsk.register.events;

import pl.gempxplay.wolfsk.register.RegisterManager;
import pl.gempxplay.wolfsk.util.doc.Element;
import pl.gempxplay.wolfsk.util.doc.Type;

import org.bukkit.event.entity.HorseJumpEvent;
import org.bukkit.event.entity.EntityTeleportEvent;
import org.bukkit.event.entity.SheepRegrowWoolEvent;

public class EntityEvents {

    public static void registerEntityEvents() {

        RegisterManager.registerEvent(new Element(Type.EVENT)
                .name("On Sheep Wool Regrow")
                .version("1.0")
                .desc("Called when player complete achivement.")
                .example("# Don't do it alone at home \non sheep wool regrow:  \n	:)")
                .usage(new String[]{
                        "on sheep wool regrow:",
                })
        , SheepRegrowWoolEvent.class);
        
        RegisterManager.registerEvent(new Element(Type.EVENT)
                .name("On Entity Teleport")
                .version("1.0")
                .desc("Called when entity teleport")
                .example("on entity teleport:  \n	send entity teleported")
                .usage(new String[]{
                        "on entity teleport:",
                })
        , EntityTeleportEvent.class);

        RegisterManager.registerEvent(new Element(Type.EVENT)
                        .name("On Horse Jump")
                        .version("1.0")
                        .desc("Called when a horse jumps.")
                        .example("# I don't know if it works :P \non horse jump:  \n	kill horse	# :O")
                        .usage(new String[]{
                                "on horse jump:",
                        })
                , HorseJumpEvent.class);


    }
}
