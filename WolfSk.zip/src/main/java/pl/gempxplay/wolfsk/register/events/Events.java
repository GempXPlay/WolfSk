package pl.gempxplay.wolfsk.register.events;

import pl.gempxplay.wolfsk.events.skript.EvtDownload;
import pl.gempxplay.wolfsk.register.RegisterManager;
import pl.gempxplay.wolfsk.util.doc.Element;
import pl.gempxplay.wolfsk.util.doc.Type;

import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.entity.HorseJumpEvent;
import org.bukkit.event.entity.EntityTeleportEvent;
import org.bukkit.event.entity.SheepRegrowWoolEvent;
import org.bukkit.event.inventory.PrepareItemCraftEvent;
import org.bukkit.event.weather.WeatherChangeEvent;
import org.bukkit.event.server.ServerListPingEvent;

public class Events {

    public static void registerEvents() {

        RegisterManager.registerEvent(new Element(Type.EVENT)
                        .name("On Download")
                        .version("1.3")
                        .desc("Called when WildSkript downloads file. ")
                        .example("on download:\n	cancel event\n	send " + '"' + "I don't allow to download" + '"' + " to console")
                        .usage(new String[]{
                                "on download:"
                        })
                , EvtDownload.class);

        RegisterManager.registerEvent(new Element(Type.EVENT)
                        .name("On Server Ping")
                        .version("1.0")
                        .desc("Called when a servers list is refreshed. In the event, you can get ip of caller.")
                        .example("on server list ping:\n	set {_ip} to ip")
                        .usage(new String[]{
                                "on [server] [list] ping:"
                        })
                , ServerListPingEvent.class);
        
        RegisterManager.registerEvent(new Element(Type.EVENT)
                .name("On Weather Changed")
                .version("1.0")
                .desc("Called when weather changed.")
                .example("unknown")
                .usage(new String[]{
                        "on weather change[d]:",
                })
        , WeatherChangeEvent.class);
        
        RegisterManager.registerEvent(new Element(Type.EVENT)
                .name("On Sheep Wool Regrow")
                .version("1.0")
                .desc("Called when player complete achivement.")
                .example("# Don't do it alone at home \non sheep wool regrow:  \n	:)")
                .usage(new String[]{
                        "on sheep wool regrow:",
                })
        , SheepRegrowWoolEvent.class);

        RegisterManager.registerEvent(new Element(Type.EVENT)
                        .name("On Prepare Item Craft")
                        .version("1.5")
                        .desc("Called when a player crafts item.")
                        .example("on prepare item craft:  \n	send " + '"' + "No idea" + '"')
                        .usage(new String[]{
                                "on prepare item craft:",
                        })
                , PrepareItemCraftEvent.class);
        
        RegisterManager.registerEvent(new Element(Type.EVENT)
                .name("On FoodLevel Changed")
                .version("1.0")
                .desc("Called when a player foodlevel changed.")
                .example("on foodlevel changed:  \n	send " + '"' + "Changed foodlevel!" + '"')
                .usage(new String[]{
                        "on foodlevel changed:",
                })
        , FoodLevelChangeEvent.class);
        
        RegisterManager.registerEvent(new Element(Type.EVENT)
                .name("On Entity Teleport")
                .version("1.0")
                .desc("Called when entity teleport")
                .example("on entity teleport:  \n	send entity teleported")
                .usage(new String[]{
                        "on entity teleport:",
                })
        , EntityTeleportEvent.class);

        RegisterManager.registerEvent(new Element(Type.EVENT)
                        .name("On Horse Jump")
                        .version("1.0")
                        .desc("Called when a horse jumps.")
                        .example("# I don't know if it works :P \non horse jump:  \n	kill horse	# :O")
                        .usage(new String[]{
                                "on horse jump:",
                        })
                , HorseJumpEvent.class);


    }
}
