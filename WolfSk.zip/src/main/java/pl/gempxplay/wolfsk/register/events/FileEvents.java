package pl.gempxplay.wolfsk.register.events;

import pl.gempxplay.wolfsk.events.skript.EvtDownload;
import pl.gempxplay.wolfsk.register.RegisterManager;
import pl.gempxplay.wolfsk.util.doc.Element;
import pl.gempxplay.wolfsk.util.doc.Type;

public class FileEvents {

    public static void registerFileEvents() {

        RegisterManager.registerEvent(new Element(Type.EVENT)
                        .name("On Download")
                        .version("1.3")
                        .desc("Called when WildSkript downloads file. ")
                        .example("on download:\n	cancel event\n	send " + '"' + "I don't allow to download" + '"' + " to console")
                        .usage(new String[]{
                                "on download:"
                        })
                , EvtDownload.class);

    }
}
