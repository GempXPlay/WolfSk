package pl.gempxplay.wolfsk.register.events;

import pl.gempxplay.wolfsk.events.skript.EvtJump;
import pl.gempxplay.wolfsk.register.RegisterManager;
import pl.gempxplay.wolfsk.util.doc.Element;
import pl.gempxplay.wolfsk.util.doc.Type;

import org.bukkit.event.enchantment.EnchantItemEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryOpenEvent;
import org.bukkit.event.inventory.PrepareItemCraftEvent;
import org.bukkit.event.player.PlayerEditBookEvent;
import org.bukkit.event.player.PlayerGameModeChangeEvent;
import org.bukkit.event.player.PlayerItemBreakEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerPickupItemEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.inventory.CraftItemEvent;

@SuppressWarnings("deprecation")
public class PlayerEvents {

    public static void registerPlayerEvents() {
    	
        RegisterManager.registerEvent(new Element(Type.EVENT)
                        .name("On Jump")
                        .version("1.5")
                        .desc("Called when player jumps")
                        .example(new String[]{
                                "on jump:",
                                "	send ''Yolo''"
                        })
                        .usage(new String[]{
                                "on jump[ing]:"
                        })
                , EvtJump.class);
        
        RegisterManager.registerEvent(new Element(Type.EVENT)
                .name("On Gamemode Changed")
                .version("1.3")
                .desc("Called when player gamemode changed. ")
                .example("no")
                .usage(new String[]{
                        "on gamemode changed:"
                })
        , PlayerGameModeChangeEvent.class);
        
        RegisterManager.registerEvent(new Element(Type.EVENT)
                .name("On Crafted")
                .version("1.3")
                .desc("Called when player crafted item in crafting. ")
                .example("no")
                .usage(new String[]{
                        "on crafted:"
                })
        , CraftItemEvent.class);
        
        RegisterManager.registerEvent(new Element(Type.EVENT)
                .name("On Placed")
                .version("1.3")
                .desc("Called when player placed block. ")
                .example("no")
                .usage(new String[]{
                        "on placed:"
                })
        , BlockPlaceEvent.class);

        RegisterManager.registerEvent(new Element(Type.EVENT)
                        .name("On Inventory Close")
                        .version("1.0")
                        .desc("Called when player closes inventory. You can't cancel the event because it's only a notification from the client.")
                        .example("on inventory close: \n	send " + '"' + "Close" + '"')
                        .usage(new String[]{
                                "on inventory open:",
                                "on close inventory:"
                        })
                , InventoryCloseEvent.class);

        RegisterManager.registerEvent(new Element(Type.EVENT)
                        .name("On Inventory Open")
                        .version("1.0")
                        .desc("Called when player opens inventory. You can't cancel the event because it's only a notification from the client, but you can use effect 'Close' :>")
                        .example("on inventory open:  \n	close player's inventory")
                        .usage(new String[]{
                                "on inventory open:",
                                "on open inventory:"
                        })
                , InventoryOpenEvent.class);

        RegisterManager.registerEvent(new Element(Type.EVENT)
                        .name("On Enchant")
                        .version("1.0")
                        .desc("Called when player enchants item.")
                        .example("on enchant:  \n	if event-item is diamond sword:\n	add 1 to {enchant.diamond.sword.%player%}")
                        .usage(new String[]{
                                "on enchant [item]:",
                        })
                , EnchantItemEvent.class);

        RegisterManager.registerEvent(new Element(Type.EVENT)
                        .name("On Any Move")
                        .version("1.0")
                        .desc("Called when a player performs any movement.")
                        .example("# Don't do it alone at home \non any move:  \n	cancel event")
                        .usage(new String[]{
                                "on any[ ]move:",
                        })
                , PlayerMoveEvent.class);
        
        RegisterManager.registerEvent(new Element(Type.EVENT)
                .name("On Pickup Item")
                .version("1.0")
                .desc("Called when player pickup item.")
                .example("# Don't do it alone at home \non pickup item:  \n	cancel event")
                .usage(new String[]{
                        "on pickup item:",
                })
        , PlayerPickupItemEvent.class);
        
        RegisterManager.registerEvent(new Element(Type.EVENT)
                .name("On Item Break")
                .version("1.0")
                .desc("Called when player item breaks.")
                .example("# Don't do it alone at home \non item break:  \n	cancel event")
                .usage(new String[]{
                        "on item break:",
                })
        , PlayerItemBreakEvent.class);     

        RegisterManager.registerEvent(new Element(Type.EVENT)
                        .name("On Inventory Click")
                        .version("1.0")
                        .desc("Called when a player performs any click in any inventory.")
                        .example("on inventory click:  \n	send " + '"' + "Click" + '"')
                        .usage(new String[]{
                                "on inventory click:",
                        })
                , InventoryClickEvent.class);
       

        RegisterManager.registerEvent(new Element(Type.EVENT)
                        .name("On Prepare Item Craft")
                        .version("1.5")
                        .desc("Called when a player crafts item.")
                        .example("on prepare item craft:  \n	send " + '"' + "No idea" + '"')
                        .usage(new String[]{
                                "on prepare item craft:",
                        })
                , PrepareItemCraftEvent.class);
        
        RegisterManager.registerEvent(new Element(Type.EVENT)
                .name("On FoodLevel Changed")
                .version("1.0")
                .desc("Called when a player foodlevel changed.")
                .example("on foodlevel changed:  \n	send " + '"' + "Changed foodlevel!" + '"')
                .usage(new String[]{
                        "on foodlevel changed:",
                })
        , FoodLevelChangeEvent.class);

        RegisterManager.registerEvent(new Element(Type.EVENT)
                        .name("On Edit Book")
                        .version("1.0")
                        .desc("Called when player edits book.")
                        .example("on book edit:  \n	send " + '"' + "Is it the Bible?" + '"')
                        .usage(new String[]{
                                "on [player] edit book:",
                        })
                , PlayerEditBookEvent.class);


    }
}
