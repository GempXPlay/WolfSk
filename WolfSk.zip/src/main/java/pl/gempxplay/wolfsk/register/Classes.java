package pl.gempxplay.wolfsk.register;

import pl.gempxplay.wolfsk.classes.AgeClasses;
import pl.gempxplay.wolfsk.classes.RegionClasses;
import pl.gempxplay.wolfsk.util.doc.Element;
import pl.gempxplay.wolfsk.util.doc.Type;

public class Classes {

    public static void registerClasses() {
        RegisterManager.registerClasses(new Element(Type.TYPE)
                        .name("Age")
                        .version("1.5")
                        .desc("Age of entity. Can be baby or adult")
                        .example("#IN BUILD")
                        .usage(new String[]{
                                "age of %entity%"
                        })
                , new AgeClasses());

        RegisterManager.registerClasses(new Element(Type.TYPE)
                        .name("Region")
                        .version("1.5")
                        .desc("Currently not applicable :C")
                        .example("set {_region} to " + '"' + "Test" + '"' + ".Region")
                        .usage(new String[]{
                                "%string%.Region"
                        })
                , new RegionClasses());
    }
}
