package pl.gempxplay.wolfsk.register;

import pl.gempxplay.wolfsk.WolfSk;
import pl.gempxplay.wolfsk.collections.Collections;
import pl.gempxplay.wolfsk.objects.Objects;
import pl.gempxplay.wolfsk.register.events.*;

public class Register {
    public static void register() {
    	
    	String l = null;
    	
        if(WolfSk.lang.contains("pl")) {
        	l = "pl";
        }
    	
    	
        Classes.registerClasses();
        if(l == "pl") {
        	WolfSk.log("Klasy zarejestrowane!");
        } else {
        	WolfSk.log("Classes registred!");
        }
        
        PlayerEvents.registerPlayerEvents();
        if(l == "pl") {
        	WolfSk.log("Ewenty gracza zarejestrowane!");
        } else {
        	WolfSk.log("Player events registred!");
        }
        
        EntityEvents.registerEntityEvents();
        if(l == "pl") {
        	WolfSk.log("Ewenty bytow zarejestrowane!");
        } else {
        	WolfSk.log("Entity events registred!");
        }
        
        FileEvents.registerFileEvents();
        if(l == "pl") {
        	WolfSk.log("Ewenty plikow zarejestrowane!");
        } else {
        	WolfSk.log("File events registred!");
        }
        
        Events.registerEvents();
        if(l == "pl") {
        	WolfSk.log("Inne ewenty zarejestrowane!");
        } else {
        	WolfSk.log("Other events registred!");
        }
        
        Conditions.registerConditions();
        if(l == "pl") {
        	WolfSk.log("Kondycje zarejestrowane!");
        } else {
        	WolfSk.log("Conditions regstred!");
        }
        
        Effects.registerEffects();
        if(l == "pl") {
        	WolfSk.log("Efekty zarejestrowane!");
        } else {
        	WolfSk.log("Effects registred!");
        }
        
        Expressions.register();
        if(l == "pl") {
        	WolfSk.log("Ekspresje zarejestrowane!");
        } else {
        	WolfSk.log("Expressions registred!");
        }

        EventValue.registerEventValues();
        if(l == "pl") {
        	WolfSk.log("Wartosci ewentowe zarejestrowane!");
        } else {
        	WolfSk.log("Event values registred!");
        }
        
        Collections.registerComplex();
        if(l == "pl") {
        	WolfSk.log("Kolekcje zarejestrowane!");
        } else {
        	WolfSk.log("Collections registred!");
        }
        
        Objects.registerObjects();
        if(l == "pl") {
        	WolfSk.log("Objekty zarejestrowane!");
        } else {
        	WolfSk.log("Objects registred!");
        }

        if(l == "pl") {
        	WolfSk.log("Wszystko pomyslnie zarejestrowano!");
        } else {
        	WolfSk.log("Succfully registred all!");
        }
    }
}
