package pl.gempxplay.wolfsk.collections;

import pl.gempxplay.wolfsk.collections.bossbar.BossHealthBarElements;
import pl.gempxplay.wolfsk.collections.functions.FunctionElements;
import pl.gempxplay.wolfsk.collections.loader.LoaderElements;
import pl.gempxplay.wolfsk.collections.obfuscator.ObfuscatorElements;
import pl.gempxplay.wolfsk.collections.packet.PacketElements;

public class Collections {

    public static void registerComplex() {
        BossHealthBarElements.register();
        FunctionElements.register();
        LoaderElements.register();
        PacketElements.register();
        ObfuscatorElements.register();
    }
}
