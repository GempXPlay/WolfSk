package pl.gempxplay.wolfsk.collections.packet;

import pl.gempxplay.wolfsk.collections.packet.elements.EffPacket;
import pl.gempxplay.wolfsk.register.RegisterManager;
import pl.gempxplay.wolfsk.util.doc.Documentation;
import pl.gempxplay.wolfsk.util.doc.Element;
import pl.gempxplay.wolfsk.util.doc.Type;

public class PacketElements {

    public static void register() {

        Documentation.addElement(new Element(Type.DESC)
                .collection("Packets")
                .name("Packets")
                .desc("Allows you to send packet to player")
        );

        RegisterManager.registerEffect(new Element(Type.COLLECTION)
                        .collection("Packets")
                        .name("Packet")
                        .desc("# Send packet from list to player")
                        .example("[player].sendPacket{[objects]};")
                        .usage(new String[]{
                                "%players%.sendPacket{[%-objects%]}[;]"
                        })
                , EffPacket.class);
    }
}
