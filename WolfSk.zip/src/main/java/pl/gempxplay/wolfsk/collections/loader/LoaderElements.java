package pl.gempxplay.wolfsk.collections.loader;

import pl.gempxplay.wolfsk.collections.loader.elements.*;
import pl.gempxplay.wolfsk.register.RegisterManager;
import pl.gempxplay.wolfsk.util.doc.Documentation;
import pl.gempxplay.wolfsk.util.doc.Element;
import pl.gempxplay.wolfsk.util.doc.Type;

public class LoaderElements {

    public static void register() {

        Documentation.addElement(new Element(Type.DESC)
                .collection("Loader")
                .name("Loader")
                .desc("Allows you to load script from file/folder/string/url")
        );

        RegisterManager.registerEffect(new Element(Type.COLLECTION)
                        .collection("Loader")
                        .name("File")
                        .desc("# Load content of file as script")
                        .example("load script from file [path]")
                        .usage(new String[]{
                                "load script from file %string%"
                        })
                , EffFile.class);

        RegisterManager.registerEffect(new Element(Type.COLLECTION)
                        .collection("Loader")
                        .name("Folder")
                        .desc("# Load Skript's file from folder")
                        .example("load scripts from folder [path]")
                        .usage(new String[]{
                                "load scripts from folder %string%"
                        })
                , EffFolder.class);

        RegisterManager.registerEffect(new Element(Type.COLLECTION)
                        .collection("Loader")
                        .name("Plugin")
                        .desc("# Enable/Disable plugin")
                        .example(new String[]{
                                "enable plugin [file]",
                                "disable plugin [name]"
                        })
                        .usage(new String[]{
                                "enable plugin %string%",
                                "disable plugin %string%"
                        })
                , EffPlugin.class);

        RegisterManager.registerEffect(new Element(Type.COLLECTION)
                        .collection("Loader")
                        .name("String")
                        .desc("# Load script from string")
                        .example("load script from [string]")
                        .usage(new String[]{
                                "load script from %string%"
                        })
                , EffString.class);

        RegisterManager.registerEffect(new Element(Type.COLLECTION)
                        .collection("Loader")
                        .name("URL")
                        .desc("# Load content of url as script")
                        .example("load script from url [url]")
                        .usage(new String[]{
                                "load script from url %string%"
                        })
                , EffURL.class);
    }
}
