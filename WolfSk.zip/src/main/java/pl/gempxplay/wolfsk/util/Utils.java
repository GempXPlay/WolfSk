package pl.gempxplay.wolfsk.util;

public class Utils {

}
