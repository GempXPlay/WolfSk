package pl.gempxplay.wolfsk.effects;

import ch.njol.skript.lang.Effect;
import ch.njol.skript.lang.Expression;
import ch.njol.skript.lang.SkriptParser;
import ch.njol.util.Kleenean;
import pl.gempxplay.wolfsk.util.MetricsLite;

import org.bukkit.event.Event;

public class EffMetrics extends Effect {

    private Expression<String> sk;
    private Expression<String> ver;

    protected void execute(Event event) {
        String sk = this.sk.getSingle(event);
        String ver = this.ver.getSingle(event);
        if (sk == null || ver == null) {
            return;
        }

        MetricsLite mcs = MetricsLite.get(sk);
        mcs.version(ver);
        mcs.start();
    }

    @SuppressWarnings("unchecked")
    public boolean init(Expression<?>[] expressions, int i, Kleenean kleenean, SkriptParser.ParseResult parseResult) {
        this.sk = (Expression<String>) expressions[0];
        this.ver = (Expression<String>) expressions[1];
        return true;
    }

    public String toString(Event event, boolean bool) {
        return this.getClass().getName();
    }
}
