package pl.gempxplay.wolfsk.effects;

import ch.njol.skript.lang.Effect;
import ch.njol.skript.lang.Expression;
import ch.njol.skript.lang.SkriptParser;
import ch.njol.util.Kleenean;
import org.bukkit.event.Event;

public class UtilComments extends Effect {

    protected void execute(Event event) {
        return;
    }

    public boolean init(Expression<?>[] expressions, int i, Kleenean kleenean, SkriptParser.ParseResult parseResult) {
        return true;
    }

    public String toString(Event event, boolean bool) {
        return this.getClass().getName();
    }

}




