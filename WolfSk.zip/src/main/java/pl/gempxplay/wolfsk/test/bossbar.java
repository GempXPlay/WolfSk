package pl.gempxplay.wolfsk.test;

import org.bukkit.entity.Player;

import org.bukkit.ChatColor;
import org.bukkit.Bukkit;
import org.bukkit.boss.*;

public class bossbar {
	
	static BossBar bar;

	public static void display(Player player, String text) {
		bar = Bukkit.createBossBar(ChatColor.translateAlternateColorCodes('&', text), BarColor.YELLOW, BarStyle.SOLID);
		
		bar.addPlayer(player);
	}
	
}
