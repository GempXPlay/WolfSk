# WildSkript [![Build Status](https://travis-ci.org/dzikoysk/WildSkript.svg?branch=master)](https://travis-ci.org/dzikoysk/WildSkript)
Addon to plugin Skript that increases the set of events, conditions, effects, expresions and this add new elements.

### Useful Links
* **DevBukkit** - http://dev.bukkit.org/bukkit-plugins/wildskript/
* **SkUnity** - https://docs.skunity.com/addon/WildSkript
